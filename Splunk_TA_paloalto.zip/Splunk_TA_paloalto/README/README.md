
This directory is used to document specs and examples that are used by Splunk.
Please do not remove the spec files in this directory or it might result in
errors while starting Splunk.